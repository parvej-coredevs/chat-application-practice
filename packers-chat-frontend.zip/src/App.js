import React from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import Users from './Users';
import { io } from 'socket.io-client';
const socket = io('ws://localhost:4000');

export default function App() {
  return (
    <main>
      <nav class='navbar navbar-expand-lg navbar-light bg-light'>
        <a class='navbar-brand' href='#'>
          Chapter App
        </a>
        <button
          class='navbar-toggler'
          type='button'
          data-toggle='collapse'
          data-target='#navbarNav'
          aria-controls='navbarNav'
          aria-expanded='false'
          aria-label='Toggle navigation'
        >
          <span class='navbar-toggler-icon'></span>
        </button>
        <div class='collapse navbar-collapse' id='navbarNav'>
          <ul class='navbar-nav ml-auto'>
            <li class='nav-item active'>
              <a class='nav-link' href='#'>
                Home <span class='sr-only'>(current)</span>
              </a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>
                Profile
              </a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>
                Contacts
              </a>
            </li>
            <li class='nav-item'>
              <a class='nav-link' href='#'>
                Settings
              </a>
            </li>
          </ul>
        </div>
      </nav>

      {/* <!-- Main Content --> */}
      <div class='container mt-4'>
        <div class='row'>
          <div class='col-md-8'>
            {/* <!-- Chat Area --> */}
            <div class='card'>
              <div class='card-header'>
                <h5>Chat with Friends</h5>
              </div>
              <div class='card-body'>{/* <!-- Chat Messages Here --> */}</div>
              <div class='card-footer'>
                <input
                  type='text'
                  class='form-control'
                  placeholder='Type your message...'
                />
                <button class='btn btn-primary mt-2'>Send</button>
              </div>
            </div>
          </div>
          <div class='col-md-4'>
            {/* <!-- Contacts Sidebar --> */}
            <div class='card'>
              <div class='card-header'>
                <h5>Contacts</h5>
              </div>
              <div class='card-body'>
                <ul class='list-group'>
                  <li class='list-group-item d-flex justify-content-between align-items-center'>
                    Friend 1
                    <span class='badge badge-primary badge-pill'>Online</span>
                  </li>
                  <li class='list-group-item d-flex justify-content-between align-items-center'>
                    Friend 2
                    <span class='badge badge-success badge-pill'>Online</span>
                  </li>
                  <li class='list-group-item d-flex justify-content-between align-items-center'>
                    Friend 3
                    <span class='badge badge-danger badge-pill'>Offline</span>
                  </li>
                  {/* <!-- Add more contacts here --> */}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
