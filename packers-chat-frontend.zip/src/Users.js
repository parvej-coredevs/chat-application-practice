import React, { useEffect, useState } from 'react';
import { useProvider } from './Provider';

/**
 * 👥 Users Component
 *
 * A component to display a form to add users and a table to show existing users.
 * The component connects to the server using Socket.io to submit and receive user data.
 *
 * 📝 Tasks:
 * 1. Form Input Validation:
 *    ✅ Validate the 'name' field. It should not be empty.
 *    ✅ Validate the 'userId' field. It should be a number greater than 0.
 *
 * 2. Socket Connection Issue:
 *    🔗 Currently, the socket is connecting to the backend multiple times. Fix it so that the socket connects only once and does not create redundant connections.
 *
 * 3. Duplicate Data Issue:
 *    🔢 Sometimes, the same data gets inserted multiple times for one submit, especially when the page is changed. Fix this issue to ensure that each user is added only once to the list of users.
 *
 * 4. Handle Continuous Submissions:
 *    🔄 If the user clicks the submit button continuously, only the last submission should be taken. The previous submissions should be ignored in such a scenario.
 *
 * 🔙 @returns {JSX.Element} The Users component.
 */
export default function Users() {
  const { users, setUsers } = useProvider();
  const [isSubmit, setIsSubmit] = useState(false);

  return (
    <>
      <h2>Hello World</h2>
    </>
  );
}
